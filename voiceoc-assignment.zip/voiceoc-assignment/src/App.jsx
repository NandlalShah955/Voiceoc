import React, { useState, useEffect } from "react";
import { Table } from "antd"; // Ant Design table for better styling
import myData from "./branch1.json";
import myData2 from "./branch2.json";

const App = () => {
  const [accounts, setAccounts] = useState([]);
  const [filteredAccounts, setFilteredAccounts] = useState([]);
  const [totalBalance, setTotalBalance] = useState(0);

  // Function to merge accounts and combine balances for duplicates
  const mergeAccounts = (data1, data2) => {
    const combinedData = [...data1, ...data2];
    const mergedData = combinedData.reduce((acc, account) => {
      const existingAccount = acc.find(
        (item) => item.accountNumber === account.accountNumber
      );
      if (existingAccount) {
        existingAccount.Balance += account.Balance;
      } else {
        acc.push({ ...account });
      }
      return acc;
    }, []);
    return mergedData;
  };

  // Calculate total balance
  const calculateTotalBalance = (data) => {
    const total = data.reduce((sum, account) => sum + account.Balance, 0);
    setTotalBalance(total.toFixed(2));
  };

  useEffect(() => {
    const mergedData = mergeAccounts(myData, myData2);
    setAccounts(mergedData);
    setFilteredAccounts(mergedData);
    calculateTotalBalance(mergedData);
  }, []);

  // Handle table change (filtering, sorting)
  const handleTableChange = (pagination, filters, sorter, extra) => {
    const { currentDataSource } = extra;
    setFilteredAccounts(currentDataSource);
    calculateTotalBalance(currentDataSource);
  };

  // Ant Design table columns configuration
  const columns = [
    {
      title: "Account Number",
      dataIndex: "accountNumber",
      key: "accountNumber",
      sorter: (a, b) => a.accountNumber - b.accountNumber,
    },
    {
      title: "Account Holder Name",
      dataIndex: "accountHolderName",
      key: "accountHolderName",
      sorter: (a, b) =>
        a.accountHolderName.localeCompare(b.accountHolderName),
    },
    {
      title: "Account Type",
      dataIndex: "accountType",
      key: "accountType",
      filters: [
        { text: "Saving", value: "saving" },
        { text: "Current", value: "current" },
      ],
      onFilter: (value, record) => record.accountType === value,
    },
    {
      title: "Balance",
      dataIndex: "Balance",
      key: "Balance",
      sorter: (a, b) => a.Balance - b.Balance,
      render: (balance) => balance.toFixed(2),
    },
  ];

  return (
    <div style={{ padding: "20px" }}>
      <h1>Accounts Table</h1>
      <Table
        dataSource={filteredAccounts}
        columns={columns}
        rowKey="accountNumber"
        pagination={{ pageSize: 5 }}
        onChange={handleTableChange}
      />
      <div style={{ marginTop: "20px", fontWeight: "bold", fontSize: "16px" }}>
        Total Balance: ${totalBalance}
      </div>
    </div>
  );
};

export default App;
